package org.exampledriven.zuul;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.netflix.config.ConfigurationManager;
import com.netflix.config.DynamicPropertyFactory;
import com.netflix.config.DynamicStringProperty;



@Component
public class ScheduledTasks {

    private static final Logger log = LoggerFactory.getLogger(ScheduledTasks.class);

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

  /*  @Scheduled(fixedRate = 5000)
    public void reportCurrentTime() {
        log.info("The time is now {}", dateFormat.format(new Date()));
    }*/
    
    @Scheduled(fixedRate = 30000)
    public void loadProperties() throws Exception {
    	
    	ConfigurationManager.loadCascadedPropertiesFromResources("application");
		DynamicStringProperty customerHost = DynamicPropertyFactory.getInstance()
				.getStringProperty("customerService.host", "");
		DynamicStringProperty authHost = DynamicPropertyFactory.getInstance()
				.getStringProperty("authService.host", "");
		DynamicStringProperty catalogueHost = DynamicPropertyFactory.getInstance()
				.getStringProperty("catalogueService.host", "");
		DynamicStringProperty orderHost = DynamicPropertyFactory.getInstance()
				.getStringProperty("orderService.host", "");
		DynamicStringProperty shippingHost = DynamicPropertyFactory.getInstance()
				.getStringProperty("shippingService.host", "");
		
		
		
		
		
    	
        log.info("The time is now {}", dateFormat.format(new Date()));
      
        
    }
    
    
}
